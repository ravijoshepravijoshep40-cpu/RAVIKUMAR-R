Optional: place DejaVuSans.ttf in this folder for robust Unicode PDF text.
If no font is present, the exporter searches common system font locations.
