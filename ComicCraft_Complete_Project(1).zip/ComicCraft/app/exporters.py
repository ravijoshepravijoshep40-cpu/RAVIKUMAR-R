from pathlib import Path
from datetime import datetime
import re
import html

from fpdf import FPDF
from PIL import Image

from app.config import BASE_DIR, EXPORTS_DIR

FONT_DIR = BASE_DIR / "assets" / "fonts"

def _find_font():
    candidates = [
        FONT_DIR / "DejaVuSans.ttf",
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
        Path("C:/Windows/Fonts/arial.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return path
    return None

def _static_to_file(web_path):
    if web_path.startswith("/static/"):
        return BASE_DIR / "static" / web_path[len("/static/"):]
    return Path(web_path)

def save_pdf(layout, title="ComicCraft Comic"):
    filename = f"comiccraft_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    output = EXPORTS_DIR / filename

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    font = _find_font()
    if font:
        pdf.add_font("DejaVu", "", str(font), uni=True)
        pdf.add_font("DejaVu", "B", str(font), uni=True)
        regular, bold = "DejaVu", "DejaVu"
    else:
        regular = bold = "Helvetica"

    for panel in layout:
        pdf.add_page()
        pdf.set_font(bold, "B", 18)
        pdf.multi_cell(0, 10, f"Panel {panel['panel_number']}: {panel['title']}")
        pdf.ln(2)

        image_file = _static_to_file(panel["image_path"])
        if image_file.exists():
            try:
                with Image.open(image_file) as im:
                    w, h = im.size
                    max_w, max_h = 180, 100
                    ratio = min(max_w / w, max_h / h)
                    pdf.image(str(image_file), w=w * ratio, h=h * ratio)
                    pdf.ln(5)
            except Exception:
                pass

        pdf.set_font(bold, "B", 11)
        pdf.multi_cell(0, 7, "Scene Description")
        pdf.set_font(regular, "", 10)
        pdf.multi_cell(0, 6, panel.get("scene_description", ""))

        pdf.set_font(bold, "B", 11)
        pdf.multi_cell(0, 7, "Caption")
        pdf.set_font(regular, "", 10)
        pdf.multi_cell(0, 6, panel.get("caption", ""))

        pdf.set_font(bold, "B", 11)
        pdf.multi_cell(0, 7, "Narration")
        pdf.set_font(regular, "", 10)
        pdf.multi_cell(0, 6, panel.get("narration", ""))

        pdf.set_font(bold, "B", 11)
        pdf.multi_cell(0, 7, "Dialogue")
        pdf.set_font(regular, "", 10)
        pdf.multi_cell(0, 6, panel.get("dialogue", ""))

    pdf.output(str(output))
    return f"/static/exports/{output.name}"
