def _story_map(story):
    return {int(item["panel_number"]): item for item in story}

def build_comic_layout(outline, story, image_paths):
    story_by_panel = _story_map(story)
    layout = []
    for index, panel in enumerate(outline):
        number = int(panel["panel_number"])
        details = story_by_panel.get(number, {})
        layout.append({
            "panel_number": number,
            "title": details.get("title") or panel.get("title", f"Panel {number}"),
            "image_path": image_paths[index],
            "scene_description": details.get("scene_description") or panel.get("scene_description", ""),
            "image_prompt": panel.get("image_prompt", ""),
            "caption": details.get("caption", ""),
            "narration": details.get("narration", ""),
            "dialogue": details.get("dialogue", ""),
        })
    return layout
