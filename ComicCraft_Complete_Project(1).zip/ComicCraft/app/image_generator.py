import io
import re
import uuid
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from app.config import (
    HF_API_KEY, SD_MODEL_ID, USE_LOCAL_DIFFUSERS,
    ALLOW_DEMO_FALLBACK, PANELS_DIR, IMAGE_SIZE
)

_pipeline = None

def _safe_name(prompt: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", prompt.lower()).strip("-")
    return (slug[:50] or "panel") + "-" + uuid.uuid4().hex[:8] + ".png"

def _demo_image(prompt: str, output: Path):
    # Lightweight offline placeholder so the complete application can run without a GPU/API.
    image = Image.new("RGB", (IMAGE_SIZE, IMAGE_SIZE), "#f4efe6")
    draw = ImageDraw.Draw(image)
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 24)
        small = ImageFont.truetype("DejaVuSans.ttf", 16)
    except Exception:
        font = small = None
    title = "COMICCRAFT"
    draw.text((30, 35), title, fill="#111827", font=font)
    wrapped = []
    words = prompt.split()
    line = ""
    for word in words:
        test = (line + " " + word).strip()
        if len(test) > 34:
            wrapped.append(line)
            line = word
        else:
            line = test
    if line:
        wrapped.append(line)
    y = 120
    for line in wrapped[:10]:
        draw.text((30, y), line, fill="#374151", font=small)
        y += 28
    draw.rounded_rectangle((50, 410, IMAGE_SIZE-50, IMAGE_SIZE-50), radius=24, outline="#111827", width=4)
    draw.text((80, 440), "Demo image mode", fill="#111827", font=small)
    image.save(output, "PNG")
    return output

def _local_diffusion(prompt: str, output: Path):
    global _pipeline
    import torch
    from diffusers import StableDiffusionPipeline
    if _pipeline is None:
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        _pipeline = StableDiffusionPipeline.from_pretrained(SD_MODEL_ID, torch_dtype=dtype)
        _pipeline = _pipeline.to("cuda" if torch.cuda.is_available() else "cpu")
    result = _pipeline(prompt, num_inference_steps=25, guidance_scale=7.5)
    result.images[0].save(output)
    return output

def _huggingface(prompt: str, output: Path):
    import requests
    if not HF_API_KEY:
        raise RuntimeError("HF_API_KEY is not configured.")
    url = f"https://api-inference.huggingface.co/models/{SD_MODEL_ID}"
    response = requests.post(
        url,
        headers={"Authorization": f"Bearer {HF_API_KEY}"},
        json={"inputs": prompt},
        timeout=180,
    )
    response.raise_for_status()
    output.write_bytes(response.content)
    Image.open(io.BytesIO(response.content)).convert("RGB").save(output)
    return output

def generate_image(prompt: str) -> str:
    output = PANELS_DIR / _safe_name(prompt)
    try:
        if USE_LOCAL_DIFFUSERS:
            _local_diffusion(prompt, output)
        elif HF_API_KEY:
            _huggingface(prompt, output)
        elif ALLOW_DEMO_FALLBACK:
            _demo_image(prompt, output)
        else:
            raise RuntimeError("Configure HF_API_KEY or enable USE_LOCAL_DIFFUSERS.")
    except Exception:
        if ALLOW_DEMO_FALLBACK:
            _demo_image(prompt, output)
        else:
            raise
    return f"/static/panels/{output.name}"
