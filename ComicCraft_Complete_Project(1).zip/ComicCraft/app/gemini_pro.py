import re
from app.config import GEMINI_API_KEY, GEMINI_PRO_MODEL, ALLOW_DEMO_FALLBACK

def _demo_story(outline, character_name, tone):
    stories = []
    for panel in outline:
        n = panel["panel_number"]
        title = panel["title"]
        desc = panel["scene_description"]
        stories.append({
            "panel_number": n,
            "title": title,
            "scene_description": desc,
            "caption": f"Panel {n}: The story moves forward.",
            "narration": f"{character_name} faces the moment with a {tone} spirit and keeps moving toward the next chapter.",
            "dialogue": f'{character_name}: "I will keep going!"'
        })
    return stories

def _parse_json(text):
    text = re.sub(r"^```(?:json)?", "", text.strip(), flags=re.I)
    text = re.sub(r"```$", "", text.strip())
    import json
    start, end = text.find("["), text.rfind("]")
    if start >= 0 and end > start:
        return json.loads(text[start:end+1])
    raise ValueError("Invalid JSON from Gemini Pro.")

def generate_story(outline, character_name, tone, story_prompt=""):
    prompt = f"""
Expand this {len(outline)}-panel comic outline into a cohesive comic story.

Character: {character_name}
Tone: {tone}
Original prompt: {story_prompt}
Outline:
{outline}

Return ONLY a JSON array. For every panel include:
panel_number, title, scene_description, caption, narration, dialogue.
Keep the story connected and preserve panel order. Dialogue should be short and natural.
"""
    if not GEMINI_API_KEY:
        if ALLOW_DEMO_FALLBACK:
            return _demo_story(outline, character_name, tone)
        raise RuntimeError("GEMINI_API_KEY is not configured.")

    try:
        from google import genai
        client = genai.Client(api_key=GEMINI_API_KEY)
        response = client.models.generate_content(
            model=GEMINI_PRO_MODEL,
            contents=prompt,
            config={"temperature": 0.9, "response_mime_type": "application/json"},
        )
        data = _parse_json(response.text)
        return data
    except Exception:
        if ALLOW_DEMO_FALLBACK:
            return _demo_story(outline, character_name, tone)
        raise
