import json
import re
from typing import Any

from app.config import GEMINI_API_KEY, GEMINI_FLASH_MODEL, ALLOW_DEMO_FALLBACK, PANELS

def _extract_json(text: str) -> Any:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text.strip(), flags=re.I)
        text = re.sub(r"```$", "", text.strip())
    start = text.find("[")
    end = text.rfind("]")
    if start >= 0 and end > start:
        return json.loads(text[start:end + 1])
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        return json.loads(text[start:end + 1])
    raise ValueError("Gemini did not return valid JSON.")

def _demo_outline(story_prompt, character_name, setting, tone, art_style):
    return [
        {
            "panel_number": i,
            "title": title,
            "scene_description": desc,
            "image_prompt": (
                f"{art_style} comic illustration, {setting}, {desc}, "
                f"main character {character_name}, cinematic composition, expressive face, "
                "consistent character design, clean line art, detailed background"
            ),
        }
        for i, (title, desc) in enumerate([
            ("The Beginning", f"{character_name} begins the adventure in {setting}, driven by the idea: {story_prompt}."),
            ("A Strange Discovery", f"{character_name} discovers an unexpected clue in {setting}."),
            ("The Challenge", f"A difficult obstacle appears and tests {character_name}'s courage."),
            ("The Turning Point", f"{character_name} finds a clever way forward and changes the situation."),
            ("A New Beginning", f"The adventure reaches a satisfying ending, leaving {character_name} with hope and a memorable lesson."),
        ], 1)
    ]

def generate_outline(story_prompt, character_name, setting, tone, art_style):
    prompt = f"""
Create exactly {PANELS} connected comic panels for this user request.

Story prompt: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Return ONLY a JSON array. Each object must contain:
panel_number (integer 1-{PANELS}), title, scene_description, image_prompt.
Keep the same main character and visual identity throughout all panels.
The image_prompt must be suitable for an image-generation model and must not contain dialogue text.
"""
    if not GEMINI_API_KEY:
        if ALLOW_DEMO_FALLBACK:
            return _demo_outline(story_prompt, character_name, setting, tone, art_style)
        raise RuntimeError("GEMINI_API_KEY is not configured.")

    try:
        from google import genai
        client = genai.Client(api_key=GEMINI_API_KEY)
        response = client.models.generate_content(
            model=GEMINI_FLASH_MODEL,
            contents=prompt,
            config={"temperature": 0.8, "response_mime_type": "application/json"},
        )
        data = _extract_json(response.text)
        if isinstance(data, dict) and "panels" in data:
            data = data["panels"]
        if not isinstance(data, list) or len(data) < PANELS:
            raise ValueError("Gemini returned an incomplete panel outline.")
        return data[:PANELS]
    except Exception:
        if ALLOW_DEMO_FALLBACK:
            return _demo_outline(story_prompt, character_name, setting, tone, art_style)
        raise
