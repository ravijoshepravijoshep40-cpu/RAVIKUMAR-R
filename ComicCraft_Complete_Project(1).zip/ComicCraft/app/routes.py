import traceback
from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from app.schemas import PromptRequest, TestImageRequest
from app.gemini_flash import generate_outline
from app.gemini_pro import generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf

router = APIRouter()
templates = Jinja2Templates(directory="templates")

def run_generation(data: PromptRequest):
    outline = generate_outline(
        data.story_prompt, data.character_name, data.setting,
        data.tone, data.art_style
    )
    story = generate_story(
        outline, data.character_name, data.tone, data.story_prompt
    )
    image_paths = [
        generate_image(panel.get("image_prompt", panel.get("scene_description", "")))
        for panel in outline
    ]
    layout = build_comic_layout(outline, story, image_paths)
    pdf_path = save_pdf(layout, title=f"{data.character_name}'s Comic")
    return outline, story, layout, pdf_path

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.post("/generate", response_class=HTMLResponse)
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        outline, story, layout, pdf_path = run_generation(data)
        return templates.TemplateResponse(
            "comic_preview.html",
            {
                "request": request,
                "layout": layout,
                "pdf_path": pdf_path,
                "character_name": data.character_name,
            },
        )
    except Exception as exc:
        traceback.print_exc()
        return templates.TemplateResponse(
            "index.html",
            {"request": request, "error": f"Comic generation failed: {exc}"},
            status_code=500,
        )

@router.post("/generate-comic/json")
async def generate_json(data: PromptRequest):
    try:
        outline, story, layout, pdf_path = run_generation(data)
        return JSONResponse({
            "success": True,
            "panels": layout,
            "pdf_path": pdf_path,
        })
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@router.post("/test-image")
async def test_image(data: TestImageRequest):
    try:
        path = generate_image(data.prompt)
        return {"success": True, "image_path": path}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request, pdf_path: str = ""):
    return templates.TemplateResponse(
        "export_success.html",
        {"request": request, "pdf_path": pdf_path},
    )

@router.get("/download")
async def download(pdf_path: str):
    # Kept as a compatibility endpoint. Browser can download the static PDF directly.
    if not pdf_path.startswith("/static/exports/"):
        raise HTTPException(status_code=400, detail="Invalid PDF path.")
    return RedirectResponse(url=pdf_path, status_code=303)
